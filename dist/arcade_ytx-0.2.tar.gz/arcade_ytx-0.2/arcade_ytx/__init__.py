from .main import run_game

run_game()
